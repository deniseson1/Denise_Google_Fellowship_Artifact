/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sun, 
  Mountain, 
  Heart, 
  Users, 
  Palette as PaletteIcon, 
  Zap, 
  Coffee, 
  Dog, 
  MapPin, 
  Camera,
  ChevronRight,
  ExternalLink,
  Sparkles
} from 'lucide-react';
import { generateBrandManifesto, BrandManifesto } from './services/geminiService';
import Markdown from 'react-markdown';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const USER_DATA = {
  name: "Denise",
  age: 26,
  location: "Arizona",
  favoriteColor: "Emerald Green, Fuchsia & Sunset Orange",
  interests: ["Painting", "Snowboarding", "Hiking", "Paddleboarding", "Golf", "Camping", "Volunteering", "Running", "Solo Travel", "Collecting Memories", "Doodling"],
  personality: ["Bubbly", "Extroverted", "Sentimental", "Analytical", "Bold", "Empathetic", "Resilient", "Curious", "Witty", "Artistic"],
  style: "Jessica Day / Anthropologie / Painterly & Vibrant",
  background: "Agricultural Arizona Roots",
  dog: {
    name: "Chips",
    breed: "Golden Doodle",
    weight: "76lb",
    role: "Passenger Prince / Soul Dog"
  },
  quotes: [
    "I’ve always loved small talk, maybe it’s just in my nature.",
    "I’m so extroverted I end up word-vomiting half my thoughts into existence.",
    "I’m not a nonchalant person. I’m quite the opposite.",
    "What a joy it was to be a small character passing through your daily life.",
    "Life’s better with Chips."
  ],
  manifestation2026: "Travel aesthetic, intentional living, summer vibes, and creative expansion."
};

const Section = ({ title, children, className, id }: { title: string; children: React.ReactNode; className?: string; id?: string }) => (
  <section id={id} className={cn("py-20 px-6 md:px-12 max-w-7xl mx-auto", className)}>
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6 }}
    >
      <div className="flex items-center gap-4 mb-12">
        <div className="h-[1px] flex-1 bg-brand-slate/20" />
        <h2 className="text-sm uppercase tracking-[0.2em] font-mono text-brand-slate/60">{title}</h2>
        <div className="h-[1px] flex-1 bg-brand-slate/20" />
      </div>
      {children}
    </motion.div>
  </section>
);

export default function App() {
  const [manifesto, setManifesto] = useState<BrandManifesto | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchManifesto() {
      try {
        const data = await generateBrandManifesto(USER_DATA);
        setManifesto(data);
      } catch (error) {
        console.error("Failed to fetch manifesto", error);
      } finally {
        setLoading(false);
      }
    }
    fetchManifesto();
  }, []);

  return (
    <div className="min-h-screen selection:bg-brand-blush selection:text-brand-crimson">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 px-6 py-4 flex justify-between items-center mix-blend-difference text-white">
        <span className="font-serif italic text-xl">Denise.</span>
        <div className="flex gap-8 text-xs uppercase tracking-widest font-mono">
          <a href="#about" className="hover:text-brand-blush transition-colors">About</a>
          <a href="#palette" className="hover:text-brand-blush transition-colors">Palette</a>
          <a href="#manifesto" className="hover:text-brand-blush transition-colors">Manifesto</a>
          <a href="#portfolio" className="hover:text-brand-blush transition-colors">Portfolio</a>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-screen flex flex-col justify-center items-center overflow-hidden bg-brand-blush text-brand-crimson">
        <div className="absolute inset-0 opacity-20 anthropologie-pattern" />
        
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="relative z-10 text-center"
        >
          <motion.div
            animate={{ rotate: [0, 5, -5, 0] }}
            transition={{ repeat: Infinity, duration: 6, ease: "easeInOut" }}
            className="inline-block mb-6"
          >
            <Sparkles size={64} className="text-brand-crimson fill-brand-crimson" />
          </motion.div>
          <h1 className="text-[15vw] md:text-[12vw] leading-[0.85] font-serif font-bold italic tracking-tighter text-brand-crimson">
            The Brand <br /> of a Life.
          </h1>
          <p className="mt-8 font-mono text-xs md:text-sm uppercase tracking-[0.3em] opacity-80 text-brand-crimson">
            Bubbly by Nature • Analytical by Design • Resilient by Choice
          </p>
        </motion.div>

        <motion.div 
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        >
          <span className="text-[10px] uppercase tracking-widest font-mono opacity-50 text-brand-crimson">Scroll to explore</span>
          <div className="w-[1px] h-12 bg-brand-crimson/30" />
        </motion.div>
      </section>

      {/* About / Identity */}
      <Section title="01. Identity" id="about">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <h3 className="text-5xl md:text-7xl leading-tight">
              An <span className="text-brand-crimson">Arizona soul</span> with a mountain heart.
            </h3>
            <p className="text-xl leading-relaxed opacity-80">
              I grew up in the agricultural parts of Arizona—survival skills in my pocket and doodles in my notebook. 
              While I daydreamed of big city lights, I learned to love the silence of the valley and the heat of the desert. 
              I'm a 26-year-old brand architect who found my rhythm between the Arizona sun and the mountain snow. 
              I’m so extroverted I end up word-vomiting half my thoughts into existence—no filter, almost to a fault. 
              I love talking to people, and I love being curious.
            </p>
            <div className="flex flex-wrap gap-3">
              {USER_DATA.personality.map((trait) => (
                <span key={trait} className="px-4 py-2 hand-drawn-border text-sm font-mono uppercase tracking-wider bg-brand-blush/20 text-brand-crimson">
                  {trait}
                </span>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="relative aspect-[3/4] rounded-2xl overflow-hidden border-4 border-brand-blush/30 shadow-2xl rotate-2">
              <img 
                src="https://picsum.photos/seed/denise-hydrangeas/600/800" 
                alt="Denise with hydrangeas" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="relative aspect-[3/4] rounded-2xl overflow-hidden border-4 border-brand-forest/30 shadow-2xl -rotate-3 mt-12">
              <img 
                src="https://picsum.photos/seed/denise-portrait-sketch/600/800" 
                alt="Denise Portrait Sketch" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      </Section>

      {/* Color Palette */}
      <Section title="02. Visual Language" id="palette" className="bg-white/50">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { name: "Petal Blush", hex: "#F8B4A6", desc: "A warm, airy peach that forms the soft foundation of my artistic world." },
            { name: "Deep Crimson", hex: "#A62626", desc: "The bold, passionate heart of a flower and the strength of my convictions." },
            { name: "Sun-Baked Clay", hex: "#F26444", desc: "The earthy, vibrant orange of an Arizona sunset and creative fire." },
            { name: "Forest Moss", hex: "#4A7337", desc: "A grounded, living green that reflects growth and resilience." },
            { name: "Azure Slate", hex: "#5C8899", desc: "A calm, sophisticated blue that adds depth and perspective." },
            { name: "Artist Canvas", hex: "#FAF3EF", desc: "The clean, inviting space where every new idea begins." }
          ].map((color, i) => (
            <motion.div 
              key={color.name}
              whileHover={{ y: -10 }}
              className="glass-card p-8 flex flex-col gap-6"
            >
              <div className="w-full aspect-square rounded-2xl shadow-inner" style={{ backgroundColor: color.hex }} />
              <div>
                <h4 className="text-2xl mb-2">{color.name}</h4>
                <p className="text-sm opacity-60 font-mono mb-4">{color.hex}</p>
                <p className="text-sm leading-relaxed">{color.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Manifesto */}
      <Section title="03. Brand Manifesto" id="manifesto">
        <div className="max-w-4xl mx-auto text-center space-y-12">
          {loading ? (
            <div className="flex flex-col items-center gap-4 py-20">
              <Sparkles className="animate-spin text-brand-clay" size={48} />
              <p className="font-mono text-xs uppercase tracking-widest">Generating Brand Voice...</p>
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-12"
            >
              <h3 className="text-4xl md:text-6xl italic leading-tight">
                "{manifesto?.tagline}"
              </h3>
              <div className="text-2xl md:text-3xl font-light leading-relaxed text-brand-ink/80 italic">
                <Markdown>{manifesto?.manifesto}</Markdown>
              </div>
              <div className="flex justify-center gap-8 pt-8">
                {manifesto?.voice.map((v) => (
                  <div key={v} className="flex flex-col items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-brand-clay" />
                    <span className="text-xs font-mono uppercase tracking-[0.2em]">{v}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </div>
      </Section>

      {/* Chips Section */}
      <Section title="04. Life's Better with Chips" className="bg-brand-blush/10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="grid grid-cols-2 gap-4">
            <div className="hand-drawn-border p-2 bg-white rotate-2 shadow-xl">
              <img 
                src="https://picsum.photos/seed/denise-chips-hill/600/800" 
                alt="Denise hugging Chips" 
                className="w-full h-auto rounded"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="hand-drawn-border p-2 bg-white -rotate-2 shadow-xl mt-8">
              <img 
                src="https://picsum.photos/seed/chips-close-up/600/800" 
                alt="Chips close up" 
                className="w-full h-auto rounded"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
          <div className="space-y-6">
            <h3 className="text-5xl italic text-brand-crimson">The reason I see so much color in this world.</h3>
            <p className="text-lg opacity-80 leading-relaxed">
              Chips is my 76lb soul dog. I wasn't planning on a dog in my 20s, but one "browse" on Puppy Finder changed everything. 
              He's my silly boy, my adventure buddy, and the reason my weekends are spent cuddling and cooking. 
              He will never know how much he changed my life.
            </p>
            <div className="grid grid-cols-2 gap-4 pt-4">
              <div className="p-4 bg-white/50 rounded-2xl border border-brand-blush/20">
                <span className="text-[10px] font-mono opacity-40 uppercase block mb-1">Weight</span>
                <span className="text-xl font-serif">76 lbs of Love</span>
              </div>
              <div className="p-4 bg-white/50 rounded-2xl border border-brand-blush/20">
                <span className="text-[10px] font-mono opacity-40 uppercase block mb-1">Role</span>
                <span className="text-xl font-serif">Passenger Prince</span>
              </div>
            </div>
          </div>
        </div>
      </Section>

      {/* Interests / Grid */}
      <Section title="05. The Ecosystem">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="col-span-2 row-span-2 glass-card p-12 flex flex-col justify-between bg-brand-forest text-brand-canvas overflow-hidden relative">
            <div className="absolute inset-0 opacity-10 vibrant-stripe" />
            <div className="relative z-10">
              <Users className="mb-6 text-brand-clay" size={40} />
              <h4 className="text-4xl mb-4">Radical Community</h4>
              <p className="opacity-80 text-lg">
                I turned strangers into friends thousands of miles from home, all because I believed one conversation could change the trajectory of someone’s day. 
                And sometimes, it really did.
              </p>
            </div>
            <div className="relative z-10 pt-8 flex gap-4">
              <div className="px-4 py-2 rounded-full bg-white/10 text-xs font-mono">SMALL TALK</div>
              <div className="px-4 py-2 rounded-full bg-white/10 text-xs font-mono">CONNECTION</div>
            </div>
          </div>

          <div className="glass-card p-0 overflow-hidden relative group">
            <img 
              src="https://picsum.photos/seed/snowboarding-action/400/400" 
              alt="Snowboarding" 
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-brand-forest/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              <Mountain size={32} className="text-white" />
            </div>
          </div>

          <div className="glass-card p-0 overflow-hidden relative group">
            <img 
              src="https://picsum.photos/seed/running-race-denise/400/400" 
              alt="Running Race" 
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-brand-blush/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              <Zap size={32} className="text-white" />
            </div>
          </div>

          <div className="col-span-2 glass-card p-8 flex items-center gap-8 bg-brand-crimson text-white relative overflow-hidden">
            <div className="absolute inset-0 opacity-10 icy-wave" />
            <div className="w-24 h-24 rounded-full bg-white/20 flex items-center justify-center shrink-0 relative z-10">
              <Sparkles size={32} className="text-brand-clay" />
            </div>
            <div className="relative z-10">
              <h5 className="font-serif text-2xl mb-2">Eclectic Spirit</h5>
              <p className="text-sm opacity-90">A blend of Jessica Day's whimsy and Anthropologie's curated patterns. Bold, unafraid, and deeply empathetic.</p>
            </div>
          </div>
        </div>
      </Section>

      {/* Painting Studio */}
      <Section title="06. The Painting Studio" className="painterly-texture">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-8">
            <h3 className="text-5xl md:text-7xl leading-tight text-brand-crimson">
              Where <span className="italic">texture</span> meets emotion.
            </h3>
            <p className="text-xl leading-relaxed opacity-80">
              Painting is where my extroverted energy finds a quiet, tactile home. 
              I love the mess of it—the thick layers of acrylic, the accidental splatters, and the way colors bleed into one another. 
              It's another way I word-vomit my thoughts, but this time, it's in strokes of clay, blush, and deep crimson.
            </p>
            <div className="grid grid-cols-2 gap-4">
              <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl border-8 border-white">
                <img 
                  src="https://picsum.photos/seed/denise-painting-floral/800/800" 
                  alt="Vibrant Floral Painting" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl border-8 border-white mt-12">
                <img 
                  src="https://picsum.photos/seed/denise-painting-vase/800/800" 
                  alt="Vase with Flowers Painting" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
          </div>
          <div className="space-y-8">
            <div className="glass-card p-6 bg-white/80 backdrop-blur-sm border-brand-clay/20">
              <PaletteIcon className="text-brand-clay mb-4" size={32} />
              <h4 className="text-2xl mb-2">The Palette</h4>
              <p className="text-sm opacity-70">My sketchbook is a living archive of experiments. I don't aim for perfection; I aim for feeling.</p>
            </div>
            <div className="aspect-[3/4] rounded-3xl overflow-hidden shadow-2xl border-8 border-white rotate-3">
              <img 
                src="https://picsum.photos/seed/denise-sketchbook-messy/600/800" 
                alt="Messy Sketchbook Page" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="aspect-video rounded-3xl overflow-hidden shadow-2xl border-8 border-white -rotate-2">
              <img 
                src="https://picsum.photos/seed/denise-painting-tools/600/400" 
                alt="Painting Tools" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      </Section>

      {/* Sentimental Archive */}
      <Section title="07. Sentimental Archive" className="bg-brand-blush/5">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="glass-card p-8 space-y-4 border-dashed border-2 border-brand-blush/40 relative bg-white">
            <div className="absolute -top-3 -right-3 bg-brand-blush text-white p-2 rounded-full rotate-12 shadow-lg">
              <Heart size={16} />
            </div>
            <h5 className="font-serif text-2xl italic text-brand-crimson">"I’m not a nonchalant person."</h5>
            <p className="text-sm leading-relaxed opacity-70">
              I love standing in the rain, booking last-minute bus rides, and solo dining at restaurants. 
              I’d rather walk than Uber, collecting little notes, cards, and receipts along the way. 
              I’m a sentimental person and I’ve come to love that about myself.
            </p>
            <div className="aspect-video rounded-xl overflow-hidden mt-4">
              <img 
                src="https://picsum.photos/seed/grass-denise/600/400" 
                alt="Denise on grass" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
          <div className="glass-card p-8 space-y-4 relative overflow-hidden bg-brand-crimson text-white">
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <MapPin size={64} />
            </div>
            <h5 className="font-serif text-2xl italic">The Arizona Soul</h5>
            <p className="text-sm leading-relaxed opacity-90">
              "To everyone I met on my journey, what a joy it was to be a small character passing through your daily life." 
              Whether in the desert or the city, I carry the warmth of my roots with me.
            </p>
            <div className="aspect-video rounded-xl overflow-hidden mt-4 border border-white/20">
              <img 
                src="https://picsum.photos/seed/lighthouse-denise/600/400" 
                alt="Denise at lighthouse" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
          <div className="glass-card p-8 space-y-4 bg-brand-forest text-white vibrant-stripe">
            <h5 className="font-serif text-2xl italic">The Word Vomit</h5>
            <p className="text-sm leading-relaxed opacity-90">
              "I’m so extroverted I end up word-vomiting half my thoughts into existence. No filter, almost to a fault."
            </p>
            <div className="flex flex-wrap gap-2 pt-4">
              {["Small Talk", "Curiosity", "Strangers", "Friends", "Conversations"].map(item => (
                <span key={item} className="text-[10px] font-mono border border-white/20 px-2 py-1 rounded bg-white/10">
                  {item}
                </span>
              ))}
            </div>
          </div>
        </div>
      </Section>

      {/* Pattern Library */}
      <Section title="08. Pattern Library" className="bg-brand-forest/5">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-4">
            <div className="h-64 rounded-3xl anthropologie-pattern border border-brand-forest/10 shadow-lg" />
            <h5 className="font-serif text-xl">The Desert Dot</h5>
            <p className="text-sm opacity-60">A rhythmic, grounded pattern inspired by Arizona landscapes.</p>
          </div>
          <div className="space-y-4">
            <div className="h-64 rounded-3xl vibrant-stripe border border-brand-blush/10 shadow-lg" />
            <h5 className="font-serif text-xl">The Vibrant Pulse</h5>
            <p className="text-sm opacity-60">A high-energy, bold pattern reflecting an extroverted spirit.</p>
          </div>
          <div className="space-y-4">
            <div className="h-64 rounded-3xl icy-wave border border-brand-slate-blue/10 shadow-lg" />
            <h5 className="font-serif text-xl">The Icy Wave</h5>
            <p className="text-sm opacity-60">A cool, flowing pattern inspired by mountain snow and winter vibes.</p>
          </div>
        </div>
      </Section>

      {/* 2026 Manifestation */}
      <Section title="09. 2026 Manifestation" className="bg-brand-canvas">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <h3 className="text-5xl md:text-7xl leading-tight text-brand-crimson">
              The <span className="italic">Future</span> is Vibrant.
            </h3>
            <p className="text-xl leading-relaxed opacity-80">
              My 2026 manifestation is about intentional expansion. It’s travel aesthetics, summer vibes, and a commitment to living a life that feels as bold as the patterns I design. 
              I’m manifesting a year of creative breakthroughs, deeper connections, and the joy of being fully present in every "small character" moment.
            </p>
            <div className="flex gap-4">
              <a 
                href="https://pin.it/5HiwwpzLI" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 bg-brand-crimson text-white rounded-full text-sm font-mono uppercase tracking-widest hover:bg-brand-crimson/90 transition-all"
              >
                View Pinterest Board <ExternalLink size={16} />
              </a>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl vibrant-stripe p-1">
              <img 
                src="https://picsum.photos/seed/travel-aesthetic/600/600" 
                alt="Travel Aesthetic" 
                className="w-full h-full object-cover rounded-[1.4rem]"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl icy-wave p-1 mt-12">
              <img 
                src="https://picsum.photos/seed/summer-vibes/600/600" 
                alt="Summer Vibes" 
                className="w-full h-full object-cover rounded-[1.4rem]"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      </Section>

      {/* Portfolio CTA */}
      <section id="portfolio" className="py-32 px-6 text-center bg-brand-crimson text-white">
        <motion.div
          whileHover={{ scale: 1.02 }}
          className="max-w-4xl mx-auto"
        >
          <h2 className="text-6xl md:text-8xl font-serif mb-8 italic">The Human <br /> Behind the Brand.</h2>
          <p className="mb-12 text-xl font-serif italic opacity-90">"I’m a sentimental person and I’ve come to love that about myself."</p>
          <a 
            href="https://www.deniseson.com/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 px-12 py-6 bg-white text-brand-crimson rounded-full text-xl font-serif hover:bg-white/90 transition-all group shadow-xl"
          >
            Explore My Work
            <ExternalLink size={24} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
          </a>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-brand-slate/10 flex flex-col md:flex-row justify-between items-center gap-8">
        <div className="flex flex-col gap-2">
          <span className="font-serif italic text-2xl">Denise.</span>
          <p className="text-xs font-mono opacity-40 uppercase tracking-widest">© 2026 Brand Guideline of a Life</p>
        </div>
        <div className="flex gap-12 text-[10px] font-mono uppercase tracking-[0.2em] opacity-60">
          <div className="flex flex-col gap-2">
            <span className="opacity-40">Location</span>
            <span>Arizona, USA</span>
          </div>
          <div className="flex flex-col gap-2">
            <span className="opacity-40">Style</span>
            <span>Bold & Bubbly</span>
          </div>
          <div className="flex flex-col gap-2">
            <span className="opacity-40">Role</span>
            <span>Brand Designer</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
