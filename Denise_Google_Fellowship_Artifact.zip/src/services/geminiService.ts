import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface BrandManifesto {
  manifesto: string;
  tagline: string;
  voice: string[];
}

export async function generateBrandManifesto(userData: any): Promise<BrandManifesto> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Based on the following description of a person, generate a brand manifesto, a tagline, and 3-5 brand voice keywords. 
    
    Description: ${JSON.stringify(userData)}
    
    The manifesto should be deeply human, sentimental, and evocative. It should capture the essence of someone who is "the opposite of nonchalant," who loves small talk, and who believes in the power of a single conversation. 
    
    Incorporate themes of:
    - Agricultural Arizona roots (desert soul, mountain heart)
    - The 76lb Golden Doodle named Chips (the "Passenger Prince")
    - Sentimental collection (notes, receipts, cards)
    - The joy of being a "small character" in others' lives
    - Extroverted curiosity and "word-vomiting" thoughts into existence
    - 2026 Manifestation: Travel, summer aesthetics, and intentional living
    
    Think "Jessica Day meets a Sentimental Archivist". 
    The tone should be warm, bold, empathetic, and unapologetically human.
    The manifesto should be 3-4 short, punchy paragraphs.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          manifesto: { type: Type.STRING },
          tagline: { type: Type.STRING },
          voice: { 
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ["manifesto", "tagline", "voice"]
      }
    }
  });

  return JSON.parse(response.text || "{}");
}
